# PhobiaGuesser <img src="icon.png" alt="PhobiaGuesser logo" width="32">
PhobiaGuesser is a minigame bot to mainly guess what a phobia is depending, to its name.

## Prefix
- ?

## Commands
- **help** --show helps
- **phobia** --get a random phobia
- **search** --look for a phobia
- **list** --get the list of all phobias
- **guess** --guess the description of a phobia

## Invite link
https://discord.com/oauth2/authorize?client_id=780066933386641428&scope=bot&permissions=8192
